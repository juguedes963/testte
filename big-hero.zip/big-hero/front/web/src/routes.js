import React from 'react'
import {Switch,Route,BrowserRouter} from 'react-router-dom'
import Register from './pages/Register'
import Login from './pages/Login'
import Profile from './pages/Profile'
import NovoCaso from './pages/NovoCaso'
export default function Routes(){
    return(
        <BrowserRouter>
            <Switch>
                
                <Route exact path='/' component={Login}/>
                <Route path="/register" component={Register}/>
                <Route path="/profile" component={Profile}/>
                <Route path="/casos/new" component={NovoCaso}/>
            </Switch>
        </BrowserRouter>
    )
}
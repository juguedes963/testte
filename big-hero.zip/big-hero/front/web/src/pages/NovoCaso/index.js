import React,{useEffect,useState} from 'react'
import './index.css'
import {FiArrowLeft} from 'react-icons/fi'
import { Link ,useHistory} from 'react-router-dom'
import Api from '../../services/api'
import logoImg from '../Login/assets/logo.png'
export default function Caso(){
    const [title,setTitle]=useState('')
    const [description,setDescription]=useState('')
    const [value,setValue]=useState('')
    const ongId=localStorage.getItem('ongId')
    const history=useHistory()
    async function handleCaso(e){
        e.preventDefault()
        const data={
            title,
            description,
            value
        }
        try{
            await Api.post('casos',data,{
                headers:{
                    Authorization:ongId,
                }
            })
            history.push('/profile')
        }catch(err){
            alert('erro ao fazer caso')
        }
    }
    return(
        <div className='register-case'>
             <div className="content">
                <section>
                    <img scr={logoImg} />
                    <h1>Cadastro</h1>
                    <p>Descreva aqui o caso Detalhado</p>
                    <Link className="back-link" to="/profile">
                        <FiArrowLeft size={16} color="red" />
                        Pagina para Home</Link>
                </section>
                <form onSubmit={handleCaso}>
                    <input value={title} onChange={(e)=>setTitle(e.target.value)} placeholder="Titulo do Cao" />
                    
                    <input value={value} onChange={(e)=>setValue(e.target.value)} placeholder="valor em Reais" />
                    <textarea  value={description} onChange={(e)=>setDescription(e.target.value)} placeholder="Descricao" />
                    <button className="button" type="submit" >Cadastrar</button>
                </form>
            </div>
        </div>
    )
}
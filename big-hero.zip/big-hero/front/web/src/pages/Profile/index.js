import React, { useEffect, useState } from 'react'
import { Link ,useHistory} from 'react-router-dom'
import { FiPower, FiTrash2 } from 'react-icons/fi'
import logoImg from '../Login/assets/logo.png'
import api from '../../services/api'
import './index.css'
export default function Profile() {
    const [casos, setCasos] = useState([])
    const history=useHistory()
    const ongId = localStorage.getItem('ongId')
    const ongName = localStorage.getItem('ongName')
  
    
    useEffect(() => {
        api.get('profile', {
            headers: {
                Authorization: ongId,
            }
        }).then(response => {
            setCasos(response.data)
        })
    }, [ongId])
   
    async function handleDelete(id){
            try {
                await api.delete(`casos/${id}`,{
                  
                })
                setCasos(casos.filter(cases=>cases.id!==id))
            } catch (error) {
                    alert("erro ao deletar")
                    console.log(error)
            }
    }
    function handleLogout(){
        localStorage.clear()
        history.push('/')
    }
    return (
        <div className="container-profile">
            <header>
                <img scr={logoImg} alt="big hero" />
                <span>bem Vindo,{ongName}</span>
                <Link className="button" to="/casos/new">Cadastrar novo Caso</Link>
                <button onClick={handleLogout}  type="button">
                    <FiPower size={18} color="red" />
                </button>
            </header>
            <h1>
                Casos Cadastrados
            </h1>
            <ul>

                {casos.map(caso => (
                    <li key={caso.id}>
                        <strong>
                            Case:
                        </strong>
                        <p>{caso.title}</p>
                        <strong>
                            Descricao:
                        </strong>
                        <p>{caso.description}</p>
                        <strong>
                            valor:
                        </strong>
                        <p>{Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(caso.value)}</p>
                        <button onClick={()=>handleDelete(caso.id)} type="button" >
                            <FiTrash2 size={20} color="gray" />
                        </button>
                    </li>
                ))}
            </ul>
        </div>
    )
}
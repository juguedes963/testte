import React from 'react';
import './global.css'
import Routers from './routes'
function App() {
  return (
    <Routers />
  );
}

export default App;

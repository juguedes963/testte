
import Constanst from 'expo-constants'
import {StyleSheet } from 'react-native'

export default StyleSheet.create({
    container:{
       flex:1,
       paddingHorizontal:24,
       paddingTop:Constanst.statusBarHeight + 20,

    },
    header:{
        flexDirection:'row',
        justifyContent:'space-between'
        ,alignItems:"center"

    },
    headerText:{
        fontSize:15,
        color:'#737380'
    },
    headerBold:{
        fontWeight:'bold'
    },
    title:{
        fontSize:30,
        marginBottom:16,
        marginTop:48,
        color:'black',
        fontWeight:'bold'
    },
    description:{
        fontSize:16,
        lineHeight:24,
        color:'#978'
    },
    casos:{
            padding:24,
            borderRadius:8,
            backgroundColor:'#FFF',
            marginBottom:16,

    },
    listaCasos:{
        marginTop:32,
    },
    casosProp:{
        fontSize:14,
        color:'black',
        fontWeight:'bold'
    },
    casosValue:{
        marginTop:8,
        fontSize:15,
        marginBottom:24,
        color:'black'
    },
    detalhesB:{
        flexDirection:'row',
        justifyContent:'space-between',
        alignItems:'center'
    },
    detalhesBText:{
        color:'red',
        fontSize:15,
        fontWeight:'bold'
    }
})
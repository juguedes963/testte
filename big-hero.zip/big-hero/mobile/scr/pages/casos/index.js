import React, { useState, useEffect } from 'react'

import { Feather } from '@expo/vector-icons'
import logo from '../../assets/logo.png'
import { useNavigation } from '@react-navigation/native'
import { View, FlatList, Image, Text, TouchableOpacity } from 'react-native'
import style from './estilos'
import api from '../../Services/api'
export default function Casos() {
    const [casos, setCasos] = useState([])
    const [total, setTotal] = useState(0)
    const [pag,setPag]=useState(1)
    const [loading,setLoading]=useState(false)

    const navigation = useNavigation()
    function navigationDel(caso) {
        navigation.navigate('detalhes',{caso})
    }
    async function loadCasos() {
        if(loading){
            return
        }
        if(total>0 && casos.length===total){
            return
        }
        setLoading(true)
        const response = await api.get('casos',{
            params:{pag}
        })
        setCasos([...casos, ...response.data])
        setTotal(response.headers['x-total-count'])
        setPag(pag+1)
        setLoading(false)
    }
    useEffect(() => {
        loadCasos()
    }, [])
    return (
        <View style={style.container} >
            <View style={style.header}>
                <Image source={logo} />
                <Text style={style.headerText}>
                    total de Casos<Text style={style.headerBold}>{total} Casos</Text>
                </Text>
            </View>
            <Text style={style.title}>Bem-vindo</Text>
            <Text style={style.description}> escolha 1 dos casos abaixo e salve o dia!</Text>
            <View style={style.listaCasos}>
                <FlatList style={style.listaCasos}
                    data={casos}
                    keyExtractor={casos => String(casos.id)}
                    showsVerticalScrollIndicator={false}
                    onEndReached={loadCasos}
                    onEndReachedThreshold={0.2}
                    renderItem={({ item: casos }) => (
                        <View style={style.casos}>
                            <Text style={style.casosProp} >ONG:</Text>
                            <Text style={style.casosValue} >{casos.name}</Text>

                            <Text style={style.casosProp} >description</Text>
                            <Text style={style.casosValue} >{casos.title}</Text>

                            <Text style={style.casosProp} >Value</Text>
                            <Text style={style.casosValue} >
                                {Intl.NumberFormat('pt-BR',
                                    {
                                        style: 'currency',
                                        currency: 'BRL'
                                    })
                                    .format(casos.value)}
                            </Text>

                            <TouchableOpacity style={style.detalhesB} onPress={()=>navigationDel(casos)} >
                                <Text style={style.detalhesBText} >Para mais detalhes</Text>
                                <Feather name="arrow-right" size={16} color="red" />
                            </TouchableOpacity>
                        </View>

                    )}
                />





            </View>
        </View>
    )
}
import Constanst from 'expo-constants'
import { StyleSheet } from 'react-native'
export default StyleSheet.create({
    container: {
        flex: 1,
        paddingHorizontal: 24,
        paddingTop: Constanst.statusBarHeight + 20,

    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between'
        , alignItems: "center",
      

    },
    caso: {
        marginTop:40,
        padding: 24,
        borderRadius: 8,
        backgroundColor: '#FFF',
        marginBottom: 16,

    },
    casosProp: {
        marginTop:8,
        fontSize: 14,
        color: 'black',
        fontWeight: 'bold'
    },
    casosValue: {
        marginTop: 8,
        fontSize: 15,
       
        color: 'black'
    },
    contact: {
      
        padding: 24,
        borderRadius: 8,
        backgroundColor: '#FFF',
        marginBottom: 16,

    },
    heroTitle:{
        fontWeight:'bold',
        fontSize:20,
        color:'black',
       lineHeight:30
    },
    heroDescription:{
        fontSize:15,
        color:'#7878',
        marginTop:16
    },
    actions:{
        marginTop:16,
        flexDirection:'row',
        justifyContent:'space-between'
    },
    action:{
        backgroundColor:'red'
        ,borderRadius:8,
        height:50,
        width:'40%',
        justifyContent:'center',
        alignItems:'center',  
    },
    actionText:{
        color:'white',
        fontSize:18,
        fontWeight:'bold'
    }
})
import React, { useEffect } from 'react'
import logo from '../../assets/logo.png'
import { useNavigation, useRoute } from '@react-navigation/native'
import { Feather } from '@expo/vector-icons'
import { View, Image, Text, TouchableOpacity, Linking } from 'react-native'
import style from './estilos'

import * as MailComposer from 'expo-mail-composer'
export default function Detalhes() {
    const navigation = useNavigation()
    const route = useRoute()
    const caso = route.params.caso
    const message = `ola ${caso.name}aaaaaaaaaaaaapaaad`
    function navigationBack() {
        navigation.goBack()
    }
    function sendMail() {
        MailComposer.composeAsync({
            subject: `heroi do caso:${caso.title}`,
            recipients: [caso.email],
            body: message,
        })
    }
    function sendWhats() {
        Linking.openURL(`whatsapp://send?phone=${caso.whatsapp}&text=${message}`)
    }
    return (
        <View style={style.container} >
            <View style={style.header}>
                <Image source={logo} />
                <TouchableOpacity onPress={navigationBack}>
                    <Feather name="arrow-left" size={30} />
                </TouchableOpacity>
            </View>
            <View style={style.caso}>
                <Text style={[style.casosProp, { marginTop: 0 }]} >ONG:</Text>
    <Text style={style.casosValue} >{caso.name} de {caso.city}/{caso.uf}</Text>

                <Text style={style.casosProp} >description</Text>
                <Text style={style.casosValue} >{caso.title}</Text>

                <Text style={style.casosProp} >Value</Text>
                <Text style={style.casosValue} >
                    {Intl.NumberFormat('pt-BR',
                        {
                            style: 'currency',
                            currency: 'BRL'
                        })
                        .format(caso.value)}
                </Text>
            </View>
            <View style={style.contact}>
                <Text style={style.heroTitle}>salve o dia</Text>

                <Text style={style.heroTitle}>seja o heroi</Text>

                <Text style={style.heroDescription}>Entrar em Contato:</Text>
                <View style={style.actions}>
                    <TouchableOpacity style={style.action} onPress={sendWhats}>
                        <Text style={style.actionText}>Whatssap</Text>

                    </TouchableOpacity>

                    <TouchableOpacity style={style.action} onPress={sendMail}>
                        <Text style={style.actionText}>E-mail</Text>

                    </TouchableOpacity>
                </View>
            </View>
        </View>
    )
}